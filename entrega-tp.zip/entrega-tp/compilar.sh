#!/usr/bin/env python

import py_compile
py_compile.compile('calcular_passos_npuzzle.py')
