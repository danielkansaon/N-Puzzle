#!/bin/bash

in="in"
out="out"

python calcular_passos_npuzzle.pyc in out